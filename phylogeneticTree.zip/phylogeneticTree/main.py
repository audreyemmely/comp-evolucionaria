import numpy as np
import seaborn as sns
import random
import skbio
import ete3
import matplotlib
matplotlib.use("Qt5Agg")
import matplotlib as plt
from algol import evolve_sequence
from algol import evolve_generation
from algol import evolve_generations
from algol import random_sequence
from skbio.alignment import global_pairwise_align_nucleotide
from skbio import DistanceMatrix
from algol import progressive_msa
from functools import partial

sequence = random_sequence(skbio.DNA, 50)
sequences = evolve_generations(sequence, generations=3, substitution_probability=0.1, indel_probability=0.05,
                               increased_rate_probability=0.1, verbose=True)
print(len(sequences))
sequences[0]
sequences[-1]
indel_probability = 0.0
sequences = evolve_generations(sequence, generations=10, substitution_probability=0.03,
                               indel_probability=0.0, increased_rate_probability=0.1, verbose=False)
sequences = random.sample(sequences, 25)
if indel_probability == 0:
	sequences_aligned = sequences
else:
	gpa = partial(global_pairwise_align_nucleotide, penalize_terminal_gaps=True)
	sequences_aligned = progressive_msa(sequences, pairwise_aligner=gpa)
ts = ete3.TreeStyle()
ts.show_leaf_name = True
ts.scale = 250
ts.branch_vertical_margin = 15
t = ete3.Tree()
t.populate(10)
t.render("mytree.png")

dm = DistanceMatrix([[0.0, 1.0, 2.0],
                      [1.0, 0.0, 3.0],
                      [2.0, 3.0, 0.0]],
                     ids=['a', 'b', 'c'])
print(dm['a', 'b'])
print(dm['b', 'c'])
img = dm.plot(cmap='Greens')
img.show()

from algol import kmer_distance
kmer_dm = DistanceMatrix.from_iterable(sequences, metric=kmer_distance, key='id')
_ = kmer_dm.plot(cmap='Greens', title='3mer distances between sequences')

from skbio.sequence.distance import hamming
hamming_dm = DistanceMatrix.from_iterable(sequences_aligned, metric=hamming, key='id')
_ = hamming_dm.plot(cmap='Greens', title='Hamming distances between sequences')

def jc_correction(p):
	return (-3/4) * np.log(1 - (4*p/3))

distances = np.arange(0, 0.70, 0.05)
jc_corrected_distances = list(map(jc_correction, distances))
ax = sns.pointplot(distances, jc_corrected_distances)
ax.set_xlabel('Hamming distance')
ax.set_ylabel('JC-corrected distance')
ax.set_xlim(0)
ax.set_ylim(0)
ax

def jc_correct_dm(dm):
    result = np.zeros(dm.shape)
    for i in range(dm.shape[0]):
    	for j in range(i):
        	result[i,j] = result[j,i] = jc_correction(dm[i,j])
    return skbio.DistanceMatrix(result, ids=dm.ids)

jc_corrected_hamming_dm = jc_correct_dm(hamming_dm)
print(hamming_dm[0])
print(jc_corrected_hamming_dm[0])
_ = jc_corrected_hamming_dm.plot(cmap='Greens', title='JC-corrected Hamming distances between sequences')
_data = np.array([[ 0.,  4.,  2.,  5.,  6.],
                  [ 4.,  0.,  3.,  6.,  5.],
                   [ 2.,  3.,  0.,  3.,  4.],
                   [ 5.,  6.,  3.,  0.,  1.],
                   [ 6.,  5.,  4.,  1.,  0.]])
_ids = ['s1', 's2', 's3', 's4', 's5']
master_upgma_dm = skbio.DistanceMatrix(_data, _ids)
print(master_upgma_dm)

iter1_ids = ['s1', 's2', 's3', '(s4, s5)']
iter1_dm = [[0.0,   4.0,  2.0, None],
             [4.0,   0.0,  3.0, None],
             [2.0,   3.0,  0.0, None],
             [None, None, None, None]]

s1_s4s5 = np.mean([master_upgma_dm['s1', 's4'], master_upgma_dm['s1', 's5']])
print(s1_s4s5)

s2_s4s5 = np.mean([master_upgma_dm['s2', 's4'], master_upgma_dm['s2', 's5']])
print(s2_s4s5)

s3_s4s5 = np.mean([master_upgma_dm['s3', 's4'], master_upgma_dm['s3', 's5']])
print(s3_s4s5)

iter1_dm = [[0.0, 4.0, 2.0, s1_s4s5],
       [4.0, 0.0, 3.0, s2_s4s5],
       [2.0, 3.0, 0.0, s3_s4s5],
       [s1_s4s5, s2_s4s5, s3_s4s5, 0.0]]

iter1_dm = DistanceMatrix(iter1_dm, iter1_ids)
print(iter1_dm)

iter2_ids = ['(s1, s3)', 's2', '(s4, s5)']
iter2_dm = [[None, None, None],
       [None,  0.0, 5.5],
       [None,  5.5, 0.0]]

s2_s1s3 = np.mean([master_upgma_dm[1][0], master_upgma_dm[1][2]])
s4s5_s1s3 = np.mean([master_upgma_dm[0][3], master_upgma_dm[0][4], master_upgma_dm[2][3], master_upgma_dm[2][4]])

iter2_dm = [[0.0, s2_s1s3, s4s5_s1s3],
             [s2_s1s3, 0.0, 5.5],
             [s4s5_s1s3, 5.5, 0.0]]

iter2_dm = DistanceMatrix(iter2_dm, iter2_ids)
print(iter2_dm)

iter3_ids = ['((s1, s3), s2)', '(s4, s5)']
iter3_dm = [[None, None],
            [None,  0.0]]

s1s2s3_s4s5 = np.mean([master_upgma_dm[0][3], master_upgma_dm[0][4],
                        master_upgma_dm[2][3], master_upgma_dm[2][4],
                        master_upgma_dm[1][3], master_upgma_dm[1][4]])

iter3_dm = [[0.0, s1s2s3_s4s5],
             [s1s2s3_s4s5, 0.0]]

iter3_dm = DistanceMatrix(iter3_dm, iter3_ids)
print(iter3_dm)

from algol import tree_from_distance_matrix
kmer_tree = tree_from_distance_matrix(kmer_dm, metric='upgma')
ete3.Tree(str(kmer_tree), format=1).render("%%inline", tree_style=ts)

jc_corrected_hamming_tree = tree_from_distance_matrix(jc_correct_dm(hamming_dm), metric='upgma')
ete3.Tree(str(jc_corrected_hamming_tree), format=1).render("%%inline", tree_style=ts)

nj_tree = tree_from_distance_matrix(jc_correct_dm(hamming_dm), metric='nj')
ete3.Tree(str(nj_tree), format=1).render("%%inline", tree_style=ts)